<?php
$BASE_URL = "https://expert-internet.net/";
$SECOND_PATH = "api/exp-v5.0/";

$sms_api_url = "http://bulksmsbd.net/api/smsapi";
$sms_api_key = "WQXz2dzA4yOM3Xo2J1AP";
$sms_api_senderid = "8809617611745";

// $sms_api_url = "http://sms.robotispsoft.net/api/smsapi";
// $sms_api_key = "JfwLvvxQxDmYYwpXYCdW";
// $sms_api_senderid = "BAYCOMBD";


