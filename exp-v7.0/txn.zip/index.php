<?php

    echo json_encode(array(
        "status" => 416,
        "message" => "Unauthorized Access!!"
    ));

?>