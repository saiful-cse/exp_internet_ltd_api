<?php
$tokenURL = "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/token/grant";
$createURL = "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/create";
$executeURL = "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/execute";
$queryURL = "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/payment/status";
$searchURL = "https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/general/searchTransaction";

$app_key = "4f6o0cjiki2rfm34kfdadl1eqq";
$app_secret = "2is7hdktrekvrbljjh44ll3d9l1dtjo4pasmjvs5vl5qr3fug4b";
$username = "sandboxTokenizedUser02";
$password = "sandboxTokenizedUser02@12345";
